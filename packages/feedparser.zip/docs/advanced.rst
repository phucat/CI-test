Advanced Features
#################

.. toctree::
   :maxdepth: 2

   date-parsing
   html-sanitization
   content-normalization
   namespace-handling
   resolving-relative-links
   version-detection
   character-encoding
   bozo













.. COMMENT: <section id="advanced.lang">
            <?dbhtml filename="language-detection.html"?>
            <sectioninfo>
            <abstract>
            <title/>
            <para>xxx</para>
            </abstract>
            </sectioninfo>
            <title>Language Detection</title>
            <para>xxx</para>
            </section>
